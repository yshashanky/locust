# Transaction Enrichment Pipeline - Kafka Streams Migration

## What's implemented
- `enrichment-data.avsc` - state store value schema (local Avro, no Schema Registry)
- `IsNeeded`, `RouteTarget`, `ProcessingResult`, `OmniPaymentMap` - core value types
- `EnrichmentDataSerde` - local binary Avro Serde for `EnrichmentData`
- `EnrichmentDataMapper` - extract-subset (on SUBMIT) / merge-if-null (on enrich) logic
- `EnrichmentProcessor` - full branch logic: UNCONFIRMED resolution, SUBMIT/COMPLETED/intermediate handling, DLQ-on-unexpected-store-miss
- `OrphanedTransactionPunctuator` - hourly (configurable) scan for orphaned entries, alert-only, does not auto-delete
- `StreamsPropertiesConfiguration` - unified StreamsConfig using `consumer.`/`producer.` prefix overrides for separate bootstrap/security/keystore
- `StreamsTopologyConfiguration` - full topology: source → transform → isNeeded branch → EnrichmentProcessor → route branch → sinks

## Must verify / adjust before this compiles and runs

1. **`XmlToAvroTransformer.transform()` and `PaymentEventMapper.map()` real signatures.**
   I called `xmlToAvroTransformer.transform(xmlPayload)` returning `List<Transaction>` (per your description) and
   `paymentEventMapper.map(intermediateEvent, partition)`. Update the `.flatMapValues()`/`.map()` chain in
   `StreamsTopologyConfiguration.topology()` to match your actual method signatures exactly.

2. **Input topic key/value types.** I assumed raw XML string in as the value with a `Serdes.String()` key/value
   `Consumed.with(...)`. Adjust to your actual input topic's real key/value serde.

3. **`debitamount` / `creditamount` types in `enrichment-data.avsc`.** Currently `["null","string"]` as a placeholder.
   Update to match the actual type in your final-event schema (e.g. `double`, or `bytes` with a `decimal` logicalType)
   so the merge logic in `EnrichmentDataMapper` doesn't silently lose precision via `.toString()`.

4. **`OrphanedTransactionPunctuator` topology wiring is the least certain piece.** Attaching a processor with no
   real data-flow parent, purely for its `schedule()` callback, isn't natively expressible via the fluent
   `StreamsBuilder` DSL. I used `StreamsBuilderFactoryBeanConfigurer.setTopologyCustomizer(...)` — **confirm this
   method exists with this exact signature in your spring-kafka 3.5.x version**, and that
   `"KSTREAM-SOURCE-0000000000"` is a valid existing parent node name in your built topology (auto-generated
   Kafka Streams node names are implementation details and may differ - print `topology.describe()` at startup
   to get the real node name, or consider a small dedicated dummy source topic feeding only this processor
   as a more robust alternative).

5. **`PaymentEventMapper`'s `isNeeded` logic** still needs to be extended by you (as you said you'd do) to return
   `IsNeeded.TRUE / FALSE / UNCONFIRMED` instead of the old boolean.

6. **Topic name placeholders** in `AppConstants` / `application.yml` need real values.

7. **Cert/keystore placeholder values** in `application.yml` need real paths/secrets (pull from your existing
   `ConsumerConfiguration`/`ProducerConfiguration` — do not commit real secrets to `application.yml` in plaintext;
   use your existing secrets-management mechanism).

## Still pending from earlier discussion (business input needed)
- Real distinct-transaction-per-month volume, for accurate RocksDB/PVC sizing (currently un-sized/unbounded in this code).
- Confirmed real max orphan lifespan threshold (currently defaulted to 720h / 30 days as a placeholder).
