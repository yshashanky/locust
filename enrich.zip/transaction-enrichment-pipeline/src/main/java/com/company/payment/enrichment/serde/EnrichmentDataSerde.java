package com.company.payment.enrichment.serde;

import com.company.payment.enrichment.avro.EnrichmentData;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;

/**
 * Plain Avro binary Serde for EnrichmentData, deliberately NOT backed by Schema Registry.
 * This data never leaves the application (state store only), so registration/compatibility
 * checks add no value here - this keeps the storage compact (Avro binary) without the
 * registry round-trip/dependency that SpecificAvroSerde would require.
 *
 * Registered directly against the generated EnrichmentData SpecificRecord class
 * (generated from src/main/avro/enrichment-data.avsc by the Avro Gradle plugin).
 */
public class EnrichmentDataSerde implements Serde<EnrichmentData> {

    @Override
    public Serializer<EnrichmentData> serializer() {
        return (topic, data) -> {
            if (data == null) {
                return null; // supports tombstones
            }
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(out, null);
                SpecificDatumWriter<EnrichmentData> writer = new SpecificDatumWriter<>(EnrichmentData.class);
                writer.write(data, encoder);
                encoder.flush();
                return out.toByteArray();
            } catch (IOException e) {
                throw new UncheckedIOException("Failed to serialize EnrichmentData", e);
            }
        };
    }

    @Override
    public Deserializer<EnrichmentData> deserializer() {
        return (topic, bytes) -> {
            if (bytes == null) {
                return null;
            }
            try {
                BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(new ByteArrayInputStream(bytes), null);
                SpecificDatumReader<EnrichmentData> reader = new SpecificDatumReader<>(EnrichmentData.class);
                return reader.read(null, decoder);
            } catch (IOException e) {
                throw new UncheckedIOException("Failed to deserialize EnrichmentData", e);
            }
        };
    }
}
