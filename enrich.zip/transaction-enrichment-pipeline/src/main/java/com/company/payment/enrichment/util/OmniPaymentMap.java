package com.company.payment.enrichment.util;

import org.apache.avro.generic.GenericRecord;

/**
 * Updated from the original boolean isNeeded field to the three-way IsNeeded enum.
 * PaymentEventMapper's isNeeded-determination logic needs to be extended to return
 * one of TRUE / FALSE / UNCONFIRMED instead of a plain boolean.
 */
public record OmniPaymentMap(GenericRecord payment, IsNeeded isNeeded) {
}
