package com.company.payment.enrichment.util;

public final class AppConstants {

    private AppConstants() {
    }

    // ---- Field names on the FINAL event (root-level GenericRecord fields) ----
    public static final String FIELD_TRANSACTION_ID = "transactionId";
    public static final String FIELD_ACTION = "action";
    public static final String FIELD_DOWNSTREAM_CORRELATION_ID = "downstreamcorrelationid";
    public static final String FIELD_PAYMENT_SCHEME = "paymentscheme";
    public static final String FIELD_DEBIT_AMOUNT = "debitamount";
    public static final String FIELD_DEBITOR_NAME = "debitorname";
    public static final String FIELD_CREDIT_AMOUNT = "creditamount";
    public static final String FIELD_CREDITOR_NAME = "creditorname";

    // ---- action field values ----
    public static final String ACTION_INITIAL = "SUBMIT";
    public static final String ACTION_TERMINAL = "COMPLETED";

    // ---- Kafka Streams state store ----
    public static final String ENRICHMENT_STORE_NAME = "transaction-enrichment-store";

    // ---- Topic name placeholders - replace with actual topic names ----
    public static final String INPUT_TOPIC = "PLACEHOLDER.input.topic";
    public static final String OUTPUT_TOPIC = "PLACEHOLDER.output.topic";
    public static final String DISCARDED_TOPIC = "PLACEHOLDER.discarded.topic";
    public static final String DLQ_TOPIC = "PLACEHOLDER.dlq.topic";

    // ---- discardReason tag values (added to discarded/DLQ payload headers for traceability) ----
    public static final String DISCARD_REASON_HEADER = "discardReason";
    public static final String DISCARD_REASON_CONFIRMED_NOT_NEEDED = "CONFIRMED_NOT_NEEDED";
    public static final String DISCARD_REASON_UNCONFIRMED_RESOLVED_FALSE = "UNCONFIRMED_RESOLVED_FALSE";
    public static final String DLQ_REASON_STORE_MISS_ON_NON_INITIAL = "STORE_MISS_ON_NON_INITIAL_EVENT";

    // ---- Configurable threshold property names (see application.yml) ----
    public static final String PROP_ORPHAN_MAX_LIFESPAN_HOURS = "enrichment.orphan.max-lifespan-hours";
    public static final String PROP_ORPHAN_CHECK_INTERVAL_MINUTES = "enrichment.orphan.check-interval-minutes";
}
