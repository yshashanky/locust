package com.company.payment.enrichment.processor;

import com.company.payment.enrichment.avro.EnrichmentData;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.processor.PunctuationType;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorContext;
import org.apache.kafka.streams.processor.api.Record;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.KeyValueStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

/**
 * Backstop for transactions that never receive a COMPLETED event (missed/lost
 * upstream, abandoned, bug). Primary cleanup is event-driven (store.delete() on
 * COMPLETED, in EnrichmentProcessor) - this punctuator ONLY catches the exception
 * case and alerts; it does not replace the primary cleanup path.
 *
 * This processor does not sit in the main data path - it's attached purely for its
 * schedule() callback and does not forward any records downstream.
 *
 * Both thresholds are configurable via application properties - see
 * AppConstants.PROP_ORPHAN_MAX_LIFESPAN_HOURS / PROP_ORPHAN_CHECK_INTERVAL_MINUTES
 * and StreamsTopologyConfiguration for how they're wired in.
 */
public class OrphanedTransactionPunctuator implements Processor<String, Void, Void, Void> {

    private static final Logger log = LoggerFactory.getLogger(OrphanedTransactionPunctuator.class);

    private final String storeName;
    private final Duration checkInterval;
    private final Duration maxLifespan;

    private KeyValueStore<String, EnrichmentData> store;

    public OrphanedTransactionPunctuator(String storeName, Duration checkInterval, Duration maxLifespan) {
        this.storeName = storeName;
        this.checkInterval = checkInterval;
        this.maxLifespan = maxLifespan;
    }

    @Override
    public void init(ProcessorContext<Void, Void> context) {
        this.store = context.getStateStore(storeName);
        context.schedule(checkInterval, PunctuationType.WALL_CLOCK_TIME, this::scanForOrphans);
    }

    private void scanForOrphans(long punctuateTimestamp) {
        long cutoff = punctuateTimestamp - maxLifespan.toMillis();
        int orphanCount = 0;

        try (KeyValueIterator<String, EnrichmentData> iterator = store.all()) {
            while (iterator.hasNext()) {
                KeyValue<String, EnrichmentData> entry = iterator.next();
                if (entry.value != null && entry.value.getInsertedAtEpochMillis() < cutoff) {
                    orphanCount++;
                    log.warn("Orphaned transaction detected: transactionId={} insertedAt={} " +
                                    "exceeds max lifespan of {} - no COMPLETED event received. " +
                                    "Alert-only, entry left in store for manual investigation.",
                            entry.key, entry.value.getInsertedAtEpochMillis(), maxLifespan);
                    // Deliberately NOT auto-deleting here - an orphan likely indicates a
                    // missed/lost COMPLETED event upstream, which is itself worth
                    // investigating rather than silently losing evidence of. Wire this
                    // warn log into your metrics/alerting pipeline (e.g. a counter metric
                    // scraped by monitoring) rather than relying on log-scraping alone.
                }
            }
        }

        if (orphanCount > 0) {
            log.warn("Orphan scan complete: {} orphaned transaction(s) found exceeding {} lifespan", orphanCount, maxLifespan);
        }
    }

    @Override
    public void process(Record<String, Void> record) {
        // no-op: this processor only exists for its scheduled punctuation callback
    }
}
