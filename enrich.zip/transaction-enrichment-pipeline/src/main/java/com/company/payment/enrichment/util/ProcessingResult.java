package com.company.payment.enrichment.util;

import org.apache.avro.generic.GenericRecord;

public record ProcessingResult(GenericRecord payload, RouteTarget target, String discardOrDlqReason) {

    public static ProcessingResult toOutput(GenericRecord payload) {
        return new ProcessingResult(payload, RouteTarget.OUTPUT, null);
    }

    public static ProcessingResult toDiscarded(GenericRecord payload, String reason) {
        return new ProcessingResult(payload, RouteTarget.DISCARDED, reason);
    }

    public static ProcessingResult toDlq(GenericRecord payload, String reason) {
        return new ProcessingResult(payload, RouteTarget.DLQ, reason);
    }
}
