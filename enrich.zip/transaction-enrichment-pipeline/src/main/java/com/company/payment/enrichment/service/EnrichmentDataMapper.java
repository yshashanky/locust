package com.company.payment.enrichment.service;

import com.company.payment.enrichment.avro.EnrichmentData;
import org.apache.avro.generic.GenericRecord;
import org.springframework.stereotype.Component;

import static com.company.payment.enrichment.util.AppConstants.*;

/**
 * Two responsibilities, kept deliberately separate even though both operate on the
 * same pair of types:
 *
 *  1. extractSubset()  - called on the INITIAL (SUBMIT) event. Pulls the EnrichmentData
 *                        subset of fields out of the full final-event GenericRecord.
 *  2. enrich()         - called on TERMINAL/intermediate events. For each field present
 *                        in both EnrichmentData and the current event, if the current
 *                        event's field is null, fill it in from the stored EnrichmentData.
 *                        EnrichmentData's field set is a strict SUBSET of the final
 *                        event's field set (confirmed) - every EnrichmentData field has
 *                        a same-named counterpart on the event, but not vice versa.
 */
@Component
public class EnrichmentDataMapper {

    public EnrichmentData extractSubset(GenericRecord event, long insertedAtEpochMillis) {
        return EnrichmentData.newBuilder()
                .setTransactionId(asString(event.get(FIELD_TRANSACTION_ID)))
                .setDownstreamcorrelationid(asString(event.get(FIELD_DOWNSTREAM_CORRELATION_ID)))
                .setPaymentscheme(asString(event.get(FIELD_PAYMENT_SCHEME)))
                .setDebitamount(asString(event.get(FIELD_DEBIT_AMOUNT)))
                .setDebitorname(asString(event.get(FIELD_DEBITOR_NAME)))
                .setCreditamount(asString(event.get(FIELD_CREDIT_AMOUNT)))
                .setCreditorname(asString(event.get(FIELD_CREDITOR_NAME)))
                .setInsertedAtEpochMillis(insertedAtEpochMillis)
                .build();
    }

    /**
     * Mutates and returns the given event: for each EnrichmentData field, if the
     * corresponding field on the event is currently null, fill it from stored data.
     * Fields already populated on the event are left untouched.
     */
    public GenericRecord enrich(GenericRecord event, EnrichmentData stored) {
        fillIfNull(event, FIELD_DOWNSTREAM_CORRELATION_ID, stored.getDownstreamcorrelationid());
        fillIfNull(event, FIELD_PAYMENT_SCHEME, stored.getPaymentscheme());
        fillIfNull(event, FIELD_DEBIT_AMOUNT, stored.getDebitamount());
        fillIfNull(event, FIELD_DEBITOR_NAME, stored.getDebitorname());
        fillIfNull(event, FIELD_CREDIT_AMOUNT, stored.getCreditamount());
        fillIfNull(event, FIELD_CREDITOR_NAME, stored.getCreditorname());
        return event;
    }

    private void fillIfNull(GenericRecord event, String fieldName, Object storedValue) {
        if (event.get(fieldName) == null && storedValue != null) {
            event.put(fieldName, storedValue);
        }
    }

    private String asString(Object value) {
        return value == null ? null : value.toString();
    }
}
