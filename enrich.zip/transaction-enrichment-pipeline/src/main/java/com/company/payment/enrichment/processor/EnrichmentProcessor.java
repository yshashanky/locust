package com.company.payment.enrichment.processor;

import com.company.payment.enrichment.avro.EnrichmentData;
import com.company.payment.enrichment.service.EnrichmentDataMapper;
import com.company.payment.enrichment.util.IsNeeded;
import com.company.payment.enrichment.util.OmniPaymentMap;
import com.company.payment.enrichment.util.ProcessingResult;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorContext;
import org.apache.kafka.streams.processor.api.Record;
import org.apache.kafka.streams.state.KeyValueStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.company.payment.enrichment.util.AppConstants.*;

/**
 * Entry point: receives (transactionId -> OmniPaymentMap) for every message that was
 * TRUE or UNCONFIRMED at the isNeeded branch (FALSE was already routed to discarded-topic
 * upstream, before rekeying - see topology).
 *
 * Responsibilities (kept as separate internal methods even though co-located):
 *  1. resolveIfUnconfirmed()  - UNCONFIRMED -> store existence check -> TRUE or FALSE
 *  2. handle SUBMIT / COMPLETED / intermediate store put/enrich/delete
 *
 * Emits a single ProcessingResult per input record; topology branches on
 * ProcessingResult.target() to route to output / discarded / DLQ topics.
 */
public class EnrichmentProcessor implements Processor<String, OmniPaymentMap, String, ProcessingResult> {

    private static final Logger log = LoggerFactory.getLogger(EnrichmentProcessor.class);

    private final String storeName;
    private final EnrichmentDataMapper mapper;

    private ProcessorContext<String, ProcessingResult> context;
    private KeyValueStore<String, EnrichmentData> store;

    public EnrichmentProcessor(String storeName, EnrichmentDataMapper mapper) {
        this.storeName = storeName;
        this.mapper = mapper;
    }

    @Override
    public void init(ProcessorContext<String, ProcessingResult> context) {
        this.context = context;
        this.store = context.getStateStore(storeName);
    }

    @Override
    public void process(Record<String, OmniPaymentMap> record) {
        String transactionId = record.key();
        GenericRecord event = record.value().payment();
        IsNeeded isNeeded = record.value().isNeeded();

        if (isNeeded == IsNeeded.UNCONFIRMED) {
            EnrichmentData existing = store.get(transactionId);
            if (existing == null) {
                forward(record, ProcessingResult.toDiscarded(event, DISCARD_REASON_UNCONFIRMED_RESOLVED_FALSE));
                return;
            }
            // resolved TRUE - fall through to normal action handling below
        }

        String action = asString(event.get(FIELD_ACTION));

        if (ACTION_INITIAL.equals(action)) {
            handleInitial(record, transactionId, event);
        } else if (ACTION_TERMINAL.equals(action)) {
            handleTerminalOrIntermediate(record, transactionId, event, true);
        } else {
            handleTerminalOrIntermediate(record, transactionId, event, false);
        }
    }

    private void handleInitial(Record<String, OmniPaymentMap> record, String transactionId, GenericRecord event) {
        EnrichmentData subset = mapper.extractSubset(event, context.currentSystemTimeMs());
        store.put(transactionId, subset);
        forward(record, ProcessingResult.toOutput(event));
    }

    private void handleTerminalOrIntermediate(Record<String, OmniPaymentMap> record, String transactionId,
                                               GenericRecord event, boolean isTerminal) {
        EnrichmentData stored = store.get(transactionId);

        if (stored == null) {
            // Should not happen given the confirmed ordering guarantee (INITIAL always
            // precedes any subsequent event for the same transactionId). If it does,
            // treat as an error condition - route to DLQ, do not silently drop or
            // silently re-interpret as INITIAL.
            log.warn("Store miss for transactionId={} on non-INITIAL action - routing to DLQ", transactionId);
            forward(record, ProcessingResult.toDlq(event, DLQ_REASON_STORE_MISS_ON_NON_INITIAL));
            return;
        }

        GenericRecord enriched = mapper.enrich(event, stored);

        if (isTerminal) {
            store.delete(transactionId);
        }

        forward(record, ProcessingResult.toOutput(enriched));
    }

    private void forward(Record<String, OmniPaymentMap> original, ProcessingResult result) {
        context.forward(new Record<>(original.key(), result, original.timestamp(), original.headers()));
    }

    private String asString(Object value) {
        return value == null ? null : value.toString();
    }
}
