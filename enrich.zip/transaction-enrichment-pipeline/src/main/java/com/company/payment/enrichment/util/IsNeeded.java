package com.company.payment.enrichment.util;

/**
 * Replaces the previous boolean isNeeded flag.
 *
 * TRUE        - message is confirmed needed; proceed to rekey + enrichment path.
 * FALSE       - message is confirmed not needed; route straight to discarded-topic,
 *               no rekey, no state store access (cheapest path).
 * UNCONFIRMED - cannot be determined from this message alone; must be rekeyed and
 *               resolved via a state store existence check inside EnrichmentProcessor.
 *               Resolves to TRUE if a store entry exists for the transactionId,
 *               otherwise resolves to FALSE (discarded).
 */
public enum IsNeeded {
    TRUE,
    FALSE,
    UNCONFIRMED
}
