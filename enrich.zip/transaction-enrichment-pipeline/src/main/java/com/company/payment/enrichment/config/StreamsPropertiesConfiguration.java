package com.company.payment.enrichment.config;

import org.apache.kafka.streams.StreamsConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Streams is a single client - it cannot literally run with two different
 * KafkaStreams instances for consume vs produce the way your old split
 * ConsumerConfiguration/ProducerConfiguration did. Instead, Kafka Streams supports
 * per-role property overrides via the "consumer." and "producer." prefixes on top
 * of the base StreamsConfig - this is the supported mechanism for giving the
 * consumer and producer sides different bootstrap servers / security / keystore,
 * while still running as one application.id / one Streams topology.
 *
 * Replace every PLACEHOLDER below with your actual property source (e.g. read
 * from application.yml via @ConfigurationProperties, or your existing cert/keystore
 * loading mechanism from the old ConsumerConfiguration/ProducerConfiguration).
 */
@Configuration
@EnableKafkaStreams
public class StreamsPropertiesConfiguration {

    @Value("${enrichment.application-id}")
    private String applicationId;

    @Value("${enrichment.state-dir}")
    private String stateDir;

    @Value("${enrichment.num-stream-threads:2}")
    private int numStreamThreads;

    @Value("${enrichment.standby-replicas:1}")
    private int numStandbyReplicas;

    // ---- consumer-side connection (own bootstrap/security/keystore) ----
    @Value("${enrichment.consumer.bootstrap-servers}")
    private String consumerBootstrapServers;
    @Value("${enrichment.consumer.security-protocol}")
    private String consumerSecurityProtocol;
    @Value("${enrichment.consumer.ssl.keystore-location}")
    private String consumerKeystoreLocation;
    @Value("${enrichment.consumer.ssl.keystore-password}")
    private String consumerKeystorePassword;
    @Value("${enrichment.consumer.ssl.truststore-location}")
    private String consumerTruststoreLocation;
    @Value("${enrichment.consumer.ssl.truststore-password}")
    private String consumerTruststorePassword;

    // ---- producer-side connection (own bootstrap/security/keystore) - also used for DLQ, same as main/discarded ----
    @Value("${enrichment.producer.bootstrap-servers}")
    private String producerBootstrapServers;
    @Value("${enrichment.producer.security-protocol}")
    private String producerSecurityProtocol;
    @Value("${enrichment.producer.ssl.keystore-location}")
    private String producerKeystoreLocation;
    @Value("${enrichment.producer.ssl.keystore-password}")
    private String producerKeystorePassword;
    @Value("${enrichment.producer.ssl.truststore-location}")
    private String producerTruststoreLocation;
    @Value("${enrichment.producer.ssl.truststore-password}")
    private String producerTruststorePassword;

    @Value("${enrichment.schema-registry.url}")
    private String schemaRegistryUrl;

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration kStreamsConfig() {
        Map<String, Object> props = new HashMap<>();

        // ---- base StreamsConfig ----
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationId);
        // bootstrap.servers is required at the top level too - Kafka Streams uses this
        // as the default for internal/repartition/changelog topics. Using the consumer
        // side's cluster here since that's where the app's internal topics should live;
        // adjust if your internal topics should be co-located with the producer cluster.
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, consumerBootstrapServers);
        props.put(StreamsConfig.STATE_DIR_CONFIG, stateDir);
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, numStreamThreads);
        props.put(StreamsConfig.NUM_STANDBY_REPLICAS_CONFIG, numStandbyReplicas);
        props.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE_V2);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.Serdes$StringSerde");

        // Schema Registry URL - standard property name expected by Confluent's
        // AbstractKafkaAvroSerDeConfig, used by SchemaProvider / registry-backed
        // GenericAvroSerde for the main/discarded/DLQ topics.
        props.put("schema.registry.url", schemaRegistryUrl);

        // ---- consumer-side overrides (source topic read) ----
        props.put(StreamsConfig.consumerPrefix(org.apache.kafka.clients.consumer.ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG),
                consumerBootstrapServers);
        props.put(StreamsConfig.consumerPrefix("security.protocol"), consumerSecurityProtocol);
        props.put(StreamsConfig.consumerPrefix("ssl.keystore.location"), consumerKeystoreLocation);
        props.put(StreamsConfig.consumerPrefix("ssl.keystore.password"), consumerKeystorePassword);
        props.put(StreamsConfig.consumerPrefix("ssl.truststore.location"), consumerTruststoreLocation);
        props.put(StreamsConfig.consumerPrefix("ssl.truststore.password"), consumerTruststorePassword);

        // ---- producer-side overrides (output/discarded/DLQ topic writes) ----
        props.put(StreamsConfig.producerPrefix(org.apache.kafka.clients.producer.ProducerConfig.BOOTSTRAP_SERVERS_CONFIG),
                producerBootstrapServers);
        props.put(StreamsConfig.producerPrefix("security.protocol"), producerSecurityProtocol);
        props.put(StreamsConfig.producerPrefix("ssl.keystore.location"), producerKeystoreLocation);
        props.put(StreamsConfig.producerPrefix("ssl.keystore.password"), producerKeystorePassword);
        props.put(StreamsConfig.producerPrefix("ssl.truststore.location"), producerTruststoreLocation);
        props.put(StreamsConfig.producerPrefix("ssl.truststore.password"), producerTruststorePassword);

        return new KafkaStreamsConfiguration(props);
    }
}
