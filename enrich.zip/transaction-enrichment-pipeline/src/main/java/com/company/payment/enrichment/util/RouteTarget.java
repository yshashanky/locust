package com.company.payment.enrichment.util;

/**
 * Kafka Streams' fluent DSL can't cleanly multi-route to different output topics
 * from inside a single Processor via context.forward(record, childName) - that
 * technique only works with the low-level Topology API's named children.
 * Instead, EnrichmentProcessor emits ONE ProcessingResult record carrying this
 * routing target, and the topology does a KStream.split() immediately after the
 * process() step to send each record to the correct .to(topic) sink.
 */
public enum RouteTarget {
    OUTPUT,
    DISCARDED,
    DLQ
}
