package com.company.payment.enrichment.config;

import com.company.payment.enrichment.avro.EnrichmentData;
import com.company.payment.enrichment.processor.EnrichmentProcessor;
import com.company.payment.enrichment.processor.OrphanedTransactionPunctuator;
import com.company.payment.enrichment.serde.EnrichmentDataSerde;
import com.company.payment.enrichment.service.EnrichmentDataMapper;
import com.company.payment.enrichment.service.PaymentEventMapper;
import com.company.payment.enrichment.service.XmlToAvroTransformer;
import com.company.payment.enrichment.util.OmniPaymentMap;
import com.company.payment.enrichment.util.ProcessingResult;
import io.confluent.kafka.streams.serdes.avro.GenericAvroSerde;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Branched;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.processor.api.ProcessorSupplier;
import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.StoreBuilder;
import org.apache.kafka.streams.state.Stores;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.kafka.config.StreamsBuilderFactoryBeanConfigurer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static com.company.payment.enrichment.util.AppConstants.*;

@Configuration
public class StreamsTopologyConfiguration {

    @Value("${enrichment.schema-registry.url}")
    private String schemaRegistryUrl;

    @Value("${" + PROP_ORPHAN_MAX_LIFESPAN_HOURS + ":720}") // default 30 days
    private long orphanMaxLifespanHours;

    @Value("${" + PROP_ORPHAN_CHECK_INTERVAL_MINUTES + ":60}") // default hourly
    private long orphanCheckIntervalMinutes;

    @Autowired
    private XmlToAvroTransformer xmlToAvroTransformer;

    @Autowired
    private PaymentEventMapper paymentEventMapper;

    @Autowired
    private EnrichmentDataMapper enrichmentDataMapper;

    @Bean
    public KStream<String, OmniPaymentMap> topology(StreamsBuilder streamsBuilder) {

        registerEnrichmentStateStore(streamsBuilder);

        GenericAvroSerde finalEventSerde = registryBackedSerde();

        // [1][2] source + XML -> Avro -> final-format transform.
        // NOTE: XmlToAvroTransformer/PaymentEventMapper are your existing services -
        // wire their real method signatures here; shown schematically since the
        // per-record shape (single object vs the List<Transaction> your transformer
        // returns) needs to be flattened via flatMapValues if it returns a list.
        KStream<String, OmniPaymentMap> mapped = streamsBuilder
                .stream(INPUT_TOPIC, Consumed.with(Serdes.String(), Serdes.String())) // raw XML string in, adjust key type to match your actual input key
                .flatMapValues(xmlPayload -> xmlToAvroTransformer.transform(xmlPayload))
                .map((key, intermediateEvent) -> {
                    OmniPaymentMap result = paymentEventMapper.map(intermediateEvent, /* partition */ 0);
                    String transactionId = (String) result.payment().get(FIELD_TRANSACTION_ID);
                    return org.apache.kafka.streams.KeyValue.pair(transactionId, result);
                });

        // [3] branch on isNeeded - FALSE goes straight to discarded, no rekey/store touch.
        Map<String, KStream<String, OmniPaymentMap>> branches = mapped.split()
                .branch((k, v) -> v.isNeeded() == com.company.payment.enrichment.util.IsNeeded.FALSE,
                        Branched.as("not-needed"))
                .defaultBranch(Branched.as("needs-enrichment")); // TRUE or UNCONFIRMED

        branches.get("branches-not-needed")
                .mapValues(OmniPaymentMap::payment)
                .to(DISCARDED_TOPIC, Produced.with(Serdes.String(), finalEventSerde));

        // [4] already keyed by transactionId from the .map() step above - no further
        // rekey/repartition needed since key was set correctly at source.

        // [5] EnrichmentProcessor - resolves UNCONFIRMED, handles SUBMIT/COMPLETED/intermediate
        ProcessorSupplier<String, OmniPaymentMap, String, ProcessingResult> processorSupplier =
                () -> new EnrichmentProcessor(ENRICHMENT_STORE_NAME, enrichmentDataMapper);

        KStream<String, ProcessingResult> processed = branches.get("branches-needs-enrichment")
                .process(processorSupplier, ENRICHMENT_STORE_NAME);

        // Route by ProcessingResult.target()
        Map<String, KStream<String, ProcessingResult>> routed = processed.split()
                .branch((k, v) -> v.target() == com.company.payment.enrichment.util.RouteTarget.OUTPUT,
                        Branched.as("route-output"))
                .branch((k, v) -> v.target() == com.company.payment.enrichment.util.RouteTarget.DISCARDED,
                        Branched.as("route-discarded"))
                .defaultBranch(Branched.as("route-dlq")); // DLQ

        routed.get("routed-route-output")
                .mapValues(ProcessingResult::payload)
                .to(OUTPUT_TOPIC, Produced.with(Serdes.String(), finalEventSerde));

        routed.get("routed-route-discarded")
                .mapValues(ProcessingResult::payload)
                .to(DISCARDED_TOPIC, Produced.with(Serdes.String(), finalEventSerde));

        routed.get("routed-route-dlq")
                .mapValues(ProcessingResult::payload)
                .to(DLQ_TOPIC, Produced.with(Serdes.String(), finalEventSerde));

        return mapped;
    }

    private void registerEnrichmentStateStore(StreamsBuilder streamsBuilder) {
        StoreBuilder<KeyValueStore<String, EnrichmentData>> storeBuilder = Stores.keyValueStoreBuilder(
                Stores.persistentKeyValueStore(ENRICHMENT_STORE_NAME),
                Serdes.String(),
                new EnrichmentDataSerde()
        );
        streamsBuilder.addStateStore(storeBuilder);
    }

    private GenericAvroSerde registryBackedSerde() {
        GenericAvroSerde serde = new GenericAvroSerde();
        Map<String, Object> config = new HashMap<>();
        config.put("schema.registry.url", schemaRegistryUrl);
        boolean isKeySerde = false;
        serde.configure(config, isKeySerde);
        return serde;
    }

    /**
     * Wires the orphan-detection punctuator into the topology. This attaches a
     * processor node with no upstream data flow, purely for its scheduled
     * punctuation callback - not expressible via the fluent StreamsBuilder DSL,
     * so it's added directly against the underlying Topology via a
     * StreamsBuilderFactoryBeanConfigurer, which spring-kafka calls before the
     * factory bean builds/starts the KafkaStreams instance.
     *
     * VERIFY against your exact spring-kafka 3.5.x API surface - the topology
     * customization hook name/signature may differ slightly; check
     * StreamsBuilderFactoryBean's available setters if this doesn't compile as-is.
     */
    @Bean
    public StreamsBuilderFactoryBeanConfigurer orphanPunctuatorConfigurer() {
        return factoryBean -> factoryBean.setTopologyCustomizer(topology -> {
            topology.addProcessor(
                    "orphan-transaction-punctuator",
                    (ProcessorSupplier<String, Object, Void, Void>) () -> (org.apache.kafka.streams.processor.api.Processor<String, Object, Void, Void>) (org.apache.kafka.streams.processor.api.Processor) new OrphanedTransactionPunctuator(
                            ENRICHMENT_STORE_NAME,
                            Duration.ofMinutes(orphanCheckIntervalMinutes),
                            Duration.ofHours(orphanMaxLifespanHours)),
                    // parent name must match whatever source/processor node precedes it -
                    // adjust to an actual existing node name in your built topology, or
                    // use topology.addSource(...) for a dedicated dummy source if needed.
                    "KSTREAM-SOURCE-0000000000"
            );
            topology.connectProcessorAndStateStores("orphan-transaction-punctuator", ENRICHMENT_STORE_NAME);
        });
    }
}
